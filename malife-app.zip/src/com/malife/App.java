package com.malife;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

public class App {

    private static final Logger log = LoggerFactory.getLogger(App.class);

    private static final String DEFAULT_SERVER_CONFIG = "/app/ground/conf/database.properties";
    private static final String FALLBACK_LOCAL_CONFIG = "config.properties";

    public static void main(String[] args) {
        log.info("=== DB Controller Application 시작 (JDK 21) ===");

        // 1. 설정 파일 경로 결정
        Path configPath = resolveConfigPath(args);
        log.info("설정 파일 경로 적용: {}", configPath.toAbsolutePath());

        Properties props = new Properties();
        try (InputStream in = new FileInputStream(configPath.toFile())) {
            props.load(in);
        } catch (IOException e) {
            log.error("설정 파일 로드 실패: {}", e.getMessage(), e);
            return;
        }

        // 2. HikariCP 커넥션 풀 설정
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl(props.getProperty("db.url"));
        hikariConfig.setUsername(props.getProperty("db.username"));
        hikariConfig.setPassword(props.getProperty("db.password"));
        hikariConfig.setMaximumPoolSize(Integer.parseInt(props.getProperty("db.pool.size", "5")));
        hikariConfig.setConnectionTimeout(Long.parseLong(props.getProperty("db.connectionTimeout", "10000")));
        hikariConfig.setPoolName("HikariPool-Main");

        HikariDataSource dataSource = null;
        try {
            dataSource = new HikariDataSource(hikariConfig);
            final HikariDataSource dsRef = dataSource;

            // 3. JVM 종료 훅 (안전한 자원 해제)
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                if (dsRef != null && !dsRef.isClosed()) {
                    log.info("JVM 종료 신호 감지: 커넥션 풀을 안전하게 닫습니다...");
                    dsRef.close();
                }
            }));

            // 4. JdbcTemplate 및 TransactionTemplate 초기화
            JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
            DataSourceTransactionManager txManager = new DataSourceTransactionManager(dataSource);
            TransactionTemplate txTemplate = new TransactionTemplate(txManager);

            // DB Ping 검증
            Integer ping = jdbcTemplate.queryForObject("SELECT 1", Integer.class);
            log.info("DB 연결 상태 확인 완료 (SELECT 1 -> {})", ping);

            // 5. 트랜잭션 단위 실행 예시
            txTemplate.execute(status -> {
                // TODO: 갱신/삽입 비즈니스 쿼리 배치
                // jdbcTemplate.update("UPDATE MY_TABLE SET UPD_DT = NOW() WHERE ID = ?", 100);
                return null;
            });

        } catch (Exception e) {
            log.error("애플리케이션 구동 또는 DB 작업 중 오류 발생: {}", e.getMessage(), e);
        } finally {
            if (dataSource != null && !dataSource.isClosed()) {
                dataSource.close();
            }
            log.info("=== DB Controller Application 정상 종료 ===");
        }
    }

    private static Path resolveConfigPath(String[] args) {
        if (args.length > 0 && args[0] != null && !args[0].isBlank()) {
            Path p = Paths.get(args[0]);
            if (Files.exists(p)) return p;
        }

        String propPath = System.getProperty("config.path");
        if (propPath != null && !propPath.isBlank()) {
            Path p = Paths.get(propPath);
            if (Files.exists(p)) return p;
        }

        Path serverDefault = Paths.get(DEFAULT_SERVER_CONFIG);
        if (Files.exists(serverDefault)) {
            return serverDefault;
        }

        Path localDefault = Paths.get(FALLBACK_LOCAL_CONFIG);
        if (Files.exists(localDefault)) {
            return localDefault;
        }

        return serverDefault;
    }
}
